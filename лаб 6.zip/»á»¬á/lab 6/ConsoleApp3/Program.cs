﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyClass1 myClass1 = new MyClass1();
            myClass1.Mef1();

        }
    }
    interface MyClass
    {

        void Mef1();

    }
    class MyClass1:MyClass
    {
        public void Mef1()
        {
            Console.WriteLine("Mef1");
        }
    }
}
